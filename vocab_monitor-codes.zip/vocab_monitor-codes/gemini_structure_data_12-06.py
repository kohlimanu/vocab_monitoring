import json
from pathlib import Path
import asyncio
from vertexai.generative_models import (
    GenerativeModel,
    GenerationConfig,
    SafetySetting,
    GenerationResponse,
)
import vertexai
import os
import random
from google.api_core.exceptions import (
    ResourceExhausted,
    InvalidArgument,
    ServiceUnavailable,
    InternalServerError,
)

PROMPT = Path("prompt.txt").read_text()


safety_settings = [
    SafetySetting(category=SafetySetting.HarmCategory.HARM_CATEGORY_HATE_SPEECH, threshold=SafetySetting.HarmBlockThreshold.OFF),
    SafetySetting(category=SafetySetting.HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT, threshold=SafetySetting.HarmBlockThreshold.OFF),
    SafetySetting(category=SafetySetting.HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT, threshold=SafetySetting.HarmBlockThreshold.OFF),
    SafetySetting(category=SafetySetting.HarmCategory.HARM_CATEGORY_HARASSMENT, threshold=SafetySetting.HarmBlockThreshold.OFF),
]

schema = {
  "type": "object",
  "properties": {
    "Transcript Segment Consolidation": { "type": "array", "items": { "type": "string" } },
    "Type-Token Ratio (TTR)": { "type": "number" },
    "Lexical Diversity": { "type": "string" },
    "Cumulative Vocabulary": {
      "type": "object",
      "properties": {
        "Count": { "type": "integer" },
        "Words": { "type": "array", "items": { "type": "string" } }
      }
    },
    "Word Category Analysis": {
      "type": "object",
      "properties": {
        "Nouns": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } },
        "Verbs": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } },
        "Adjectives": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } },
        "Adverbs": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } },
        "Pronouns": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } },
        "Prepositions": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } },
        "Conjunctions": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } },
        "Articles": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } },
        "Interjections": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } },
        "Emotion Words": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } },
        "Academic Vocabulary": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } },
        "Social Words": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } },
        "Social Phrases": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } },
        "Possessive Words": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } },
        "Temporal Words": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } },
        "Quantifiers": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } },
        "Sensory Words": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } },
        "Imaginative Words": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } },
        "Question Words": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } }
      }
    },
    "Mean Length of Utterance (MLU)": { "type": "number" },
    "Multi-word vs. Single-word Utterances": {
      "type": "object",
      "properties": {
        "Multi-word Utterances": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } },
        "Single-word Utterances": { "type": "object", "properties": { "Count": { "type": "integer" }, "Examples": { "type": "array", "items": { "type": "string" } } } }
      }
    }
  },
  "required": ["Transcript Segment Consolidation", "Type-Token Ratio (TTR)", "Lexical Diversity", "Cumulative Vocabulary", "Word Category Analysis", "Mean Length of Utterance (MLU)", "Multi-word vs. Single-word Utterances"]
}


async def gemini_classify(video_part) -> GenerationResponse:
    vertexai.init(project="frontera-data-resources", location="us-central1")
    model = GenerativeModel("gemini-2.0-flash-001")

    generation_config = GenerationConfig(
        max_output_tokens=8192,
        temperature=0.2,
        top_p=0.95,
        response_mime_type="application/json",
        response_schema=schema
    )

    attempts = 0
    sleep_time = 1.0
    while True:
        try:
            response: GenerationResponse = await model.generate_content_async(
                [PROMPT, video_part],
                generation_config=generation_config,
                safety_settings=safety_settings,
            )
        except (ResourceExhausted, ServiceUnavailable, InternalServerError) as e:
            attempts += 1
            if attempts >= 20:
                raise e
            sleep_time = min(sleep_time * 2, 60)
            sleep_time += sleep_time * 0.1 * (random.random() - 0.5)
            await asyncio.sleep(sleep_time)
        except InvalidArgument as e:
            return "Failed to generate content: InvalidArgument"
        else:
            break
    return response


def extract_child_lines_from_srt(lines):
    """Extract only [CHILD] utterances from SRT lines"""
    child_lines = []
    buffer = []
    for line in lines:
        line = line.strip()
        if "-->" in line or not line:
            continue
        if line.endswith("[CHILD]"):
            # Remove speaker tag and extra whitespace
            content = line.rsplit("[CHILD]", 1)[0].strip()
            if content:
                child_lines.append(content)
    return child_lines


async def process_transcript(transcript_path: Path):
    with open(transcript_path, "r", encoding="utf-8") as f:
        lines = f.readlines()

    child_utterances = extract_child_lines_from_srt(lines)
    chunks = [child_utterances[i:i + 25] for i in range(0, len(child_utterances), 25)]
    results = []

    for i, chunk in enumerate(chunks):
        text_chunk = "\n".join(chunk)
        try:
            result = await gemini_classify(text_chunk)
            if isinstance(result, str):
                print(f"Chunk {i}: received string response, skipping")
                continue
            data = json.loads(result.text)
            results.append(data)
        except Exception as e:
            print(f"Error processing chunk {i} of {transcript_path.name}: {e}")

    out_path = OUTPUT_PATH / f"{transcript_path.stem}_gemini_metrics.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)

    print(f"Saved: {out_path.name}")


async def batch_process_transcripts(transcript_dir="transcripts"):
    transcript_dir = Path(transcript_dir)
    transcript_paths = sorted(transcript_dir.glob("*.srt"))
    
    for path in transcript_paths:
        print(f"Processing {path.name}")
        await process_transcript(path)

    print("All transcripts processed.")


if __name__ == "__main__":
    OUTPUT_PATH = Path("output_learner_9")
    OUTPUT_PATH.mkdir(exist_ok=True)
    asyncio.run(batch_process_transcripts(transcript_dir="/home/varun/code/vocab-monitor/l_9_all"))
