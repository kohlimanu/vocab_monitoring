import os
import json
import re
from collections import defaultdict
from datetime import datetime
import glob

def extract_month_from_filename(filename):
    match = re.search(r'_(\d{4}-\d{2})-\d{2}_syntactic_metrics\.json$', filename)
    return match.group(1) if match else None

def generate_syntactic_structure_html(json_files, output_dir="outputs"):
    month_data = defaultdict(lambda: defaultdict(lambda: {"count": 0, "examples": []}))

    for json_file in json_files:
        month = extract_month_from_filename(os.path.basename(json_file))
        if not month:
            continue

        with open(json_file, "r", encoding="utf-8") as f:
            data = json.load(f)

        for entry in data:
            for sentence_type, details in entry.items():
                if isinstance(details, dict) and "Count" in details:
                    month_data[month][sentence_type]["count"] += details["Count"]
                    month_data[month][sentence_type]["examples"].extend(details.get("Examples", []))
                elif sentence_type == "Interrogative Sentences":
                    for subtype, subdetails in details.items():
                        full_type = f"Interrogative - {subtype}"
                        month_data[month][full_type]["count"] += subdetails["Count"]
                        month_data[month][full_type]["examples"].extend(subdetails.get("Examples", []))

    sorted_months = sorted(month_data.keys())

    html = """
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Monthly Syntactic Structure Summary</title>
<style>
  body { font-family: Arial, sans-serif; margin: 20px; }
  h1 { text-align: center; }
  table { border-collapse: collapse; width: 100%; }
  th, td { border: 1px solid #ccc; padding: 8px; vertical-align: top; }
  th { background-color: #f2f2f2; }
  .count { font-weight: bold; color: #003366; }
  .examples { color: #555; font-style: italic; }
</style>
</head>
<body>
<h1>Monthly Syntactic Structure Summary</h1>
"""

    for month in sorted_months:
        html += f"<h2>{month}</h2><table><thead><tr><th>Sentence Type</th><th>Count</th><th>Examples</th></tr></thead><tbody>"
        for sentence_type, details in sorted(month_data[month].items()):
            unique_examples = sorted(set(details["examples"]))
            examples = "<br>".join(unique_examples[:5]) if unique_examples else "—"
            html += f"<tr><td>{sentence_type}</td><td class='count'>{details['count']}</td><td class='examples'>{examples}</td></tr>"
        html += "</tbody></table><br>"

    html += "</body></html>"

    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, "syntactic_structure_summary.html")
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"HTML summary written to: {output_path}")



json_files = glob.glob("/home/varun/code/vocab-monitor/output_syntactic_structure_learner_9/*_syntactic_metrics.json")
generate_syntactic_structure_html(json_files, output_dir="graph_syntactic_metrics_learner_9")