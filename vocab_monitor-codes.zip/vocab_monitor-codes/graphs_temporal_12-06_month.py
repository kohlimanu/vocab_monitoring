import json
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
from glob import glob
import re
import logging
from collections import defaultdict

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

sns.set(style="whitegrid", font_scale=1.2)

json_dir = "/home/varun/code/vocab-monitor/output_learner_9/"
csv_dir = "/home/varun/code/vocab-monitor/output_learner_9_nlp/"
output_dir = "graphs_monthly_learner_" + csv_dir.split("learner_")[1].split("_")[0]

os.makedirs(output_dir, exist_ok=True)

json_files = sorted(glob(os.path.join(json_dir, "*_gemini_metrics.json")))
csv_files = sorted(glob(os.path.join(csv_dir, "*_ttr_results.csv")))

def extract_yyyymm(filename):
    match = re.search(r"(\d{4}-\d{2})-\d{2}", filename)
    return match.group(1) if match else None

all_categories = [
    "Nouns", "Verbs", "Adjectives", "Adverbs", "Pronouns", "Prepositions",
    "Conjunctions", "Articles", "Interjections", "Emotion Words", "Academic Vocabulary",
    "Social Words", "Social Phrases", "Possessive Words", "Temporal Words",
    "Quantifiers", "Sensory Words", "Imaginative Words", "Question Words"
]

# Group files by month
json_by_month = defaultdict(list)
csv_by_month = defaultdict(list)

for f in json_files:
    month = extract_yyyymm(os.path.basename(f))
    if month:
        json_by_month[month].append(f)

for f in csv_files:
    month = extract_yyyymm(os.path.basename(f))
    if month:
        csv_by_month[month].append(f)

monthly_data = []
month_word_data = {}

for month in sorted(json_by_month.keys()):
    if month not in csv_by_month:
        continue

    json_group = json_by_month[month]
    csv_group = csv_by_month[month]

    total_duration_min = 0
    total_vocab_count = 0
    total_multi = 0
    total_single = 0
    category_counts = {cat: 0 for cat in all_categories}
    ttr_values = []
    mlu_values = []
    word_freq = {}

    for json_file, csv_file in zip(json_group, csv_group):
        try:
            with open(json_file, "r") as f:
                data = json.load(f)
            csv_data = pd.read_csv(csv_file)
            duration_sec = float(csv_data["ASR_Conversational_Duration"].iloc[0])
            if duration_sec == 0:
                logging.warning(f"Zero duration in {csv_file}. Skipping.")
                continue
            duration_min = duration_sec / 60
        except Exception as e:
            logging.warning(f"Error reading files for {month}: {e}")
            continue

        total_duration_min += duration_min
        total_vocab_count += data[-1]["Cumulative Vocabulary"]["Count"]

        for seg in data:
            wca = seg.get("Word Category Analysis", {})
            for cat in all_categories:
                category_counts[cat] += wca.get(cat, {}).get("Count", 0)
            total_multi += seg["Multi-word vs. Single-word Utterances"]["Multi-word Utterances"]["Count"]
            total_single += seg["Multi-word vs. Single-word Utterances"]["Single-word Utterances"]["Count"]
            vocab = seg.get("Cumulative Vocabulary", {}).get("Words", [])
            for w in vocab:
                word_freq[w] = word_freq.get(w, 0) + 1

        ttr_values.append(csv_data["TTR_NLP"].iloc[0])
        mlu_values.append(csv_data["MLU"].iloc[0])

    if total_duration_min == 0:
        continue

    monthly_data.append({
        "Month": month,
        "VocabCount": total_vocab_count / total_duration_min,
        "MultiWord": total_multi / total_duration_min,
        "SingleWord": total_single / total_duration_min,
        "TTR_NLP": sum(ttr_values) / len(ttr_values),
        "MLU": sum(mlu_values) / len(mlu_values),
        **{cat: count / total_duration_min for cat, count in category_counts.items()}
    })

    sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
    common_words = sorted_words[:10]
    unique_words = [w for w, freq in sorted_words if freq == 1][:10]
    month_word_data[month] = (common_words, unique_words)

# === DataFrame & Rolling Averages ===
df = pd.DataFrame(monthly_data).sort_values("Month")
df["Months"] = pd.to_datetime(df["Month"], format="%Y-%m").dt.to_period("M").astype(str)
df = df.set_index("Months")

def compute_rolling_averages(df, window=3):
    numeric_cols = df.select_dtypes(include="number").columns
    return df[numeric_cols].rolling(window=window, min_periods=1).mean()

rolling_window = 3
df_rolling = compute_rolling_averages(df, window=rolling_window)

# === Plot 1: Vocabulary Growth ===
plt.figure(figsize=(8, 5))
sns.lineplot(x=df.index, y=df["VocabCount"], marker="o", color="darkblue", label="Original")
sns.lineplot(x=df_rolling.index, y=df_rolling["VocabCount"], marker="o", color="orange", label=f"{rolling_window}-Month Rolling Avg")
plt.title("Cumulative Vocabulary Growth (Normalized per Minute)")
plt.ylabel("Unique Words per Minute")
plt.xticks(rotation=45)
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "temporal_vocab_growth_rolling.png"))

# === Plot 2: MLU and TTR ===
plt.figure(figsize=(10, 5))
sns.lineplot(x=df.index, y=df["MLU"], marker="o", label="MLU Original", color="indianred")
sns.lineplot(x=df_rolling.index, y=df_rolling["MLU"], marker="o", label=f"MLU {rolling_window}-Month Rolling Avg", color="tomato")
sns.lineplot(x=df.index, y=df["TTR_NLP"], marker="o", label="TTR Original", color="seagreen")
sns.lineplot(x=df_rolling.index, y=df_rolling["TTR_NLP"], marker="o", label=f"TTR {rolling_window}-Month Rolling Avg", color="mediumseagreen")
plt.title("MLU and TTR Trends")
plt.ylabel("Score")
plt.legend()
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "temporal_mlu_ttr_rolling.png"))

# === Plot 3: Multi vs Single Word Utterances ===
utter_df = df.reset_index()[["Month", "MultiWord", "SingleWord"]].melt(id_vars="Month", var_name="Type", value_name="Count")
plt.figure(figsize=(10, 6))
sns.barplot(data=utter_df, x="Month", y="Count", hue="Type", palette="pastel",  ci=None)
plt.title("Multi vs. Single Word Utterances (Normalized per Minute)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "temporal_utterance_types.png"))

# === Plot 4: Word Category Heatmap ===
heatmap_df = df[all_categories]
heatmap_rolling_df = df_rolling[all_categories]

plt.figure(figsize=(14, 8))
sns.heatmap(heatmap_df, annot=True, fmt=".2f", cmap="YlOrBr", cbar_kws={'label': 'Count/min'}, linewidths=0.5)
plt.title("Word Category Usage Over Time (Normalized per Minute)")
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "temporal_word_categories_heatmap.png"))

plt.figure(figsize=(14, 8))
sns.heatmap(heatmap_rolling_df, annot=True, fmt=".2f", cmap="YlOrBr", cbar_kws={'label': f'Count/min ({rolling_window}-Month Avg)'}, linewidths=0.5)
plt.title(f"Word Category Usage Over Time ({rolling_window}-Month Rolling Avg)")
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "temporal_word_categories_heatmap_rolling.png"))

logging.info("All Graphs generated successfully.")
logging.info("Output directory: %s", output_dir)

# === HTML Report ===
html_content = """
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Monthly Word Summary</title>
<style>
  body { font-family: Arial, sans-serif; margin: 20px; }
  h1 { text-align: center; }
  table { border-collapse: collapse; width: 100%; table-layout: fixed; }
  th, td { border: 1px solid #ddd; padding: 8px; vertical-align: top; word-wrap: break-word; }
  th { background-color: #f2f2f2; text-align: center; }
  .common { color: navy; font-family: monospace; }
  .unique { color: darkred; font-family: monospace; }
  tbody tr:hover { background-color: #f1f1f1; }
</style>
</head>
<body>
<h1>Monthly Most Common and Unique Words Overview</h1>
<table>
<thead>
<tr>
  <th style="width: 8%;">Month</th>
  <th style="width: 46%;">Top 10 Most Common Words (word: count)</th>
  <th style="width: 46%;">Top 10 Unique Words (freq=1)</th>
</tr>
</thead>
<tbody>
"""

for month in sorted(month_word_data.keys()):
    common_words, unique_words = month_word_data[month]
    common_html = "<br>".join([f"{w}: {freq}" for w, freq in common_words])
    unique_html = "<br>".join(unique_words)
    html_content += f"""
    <tr>
      <td style="text-align: center; font-weight: bold;">{month}</td>
      <td class="common">{common_html}</td>
      <td class="unique">{unique_html}</td>
    </tr>
    """

html_content += """
</tbody>
</table>
</body>
</html>
"""

output_html_path = os.path.join(output_dir, "monthly_word_summary.html")
with open(output_html_path, "w", encoding="utf-8") as f:
    f.write(html_content)

logging.info("Monthly Word Summary HTML generated successfully.")
logging.info("Output HTML: %s", output_html_path)
