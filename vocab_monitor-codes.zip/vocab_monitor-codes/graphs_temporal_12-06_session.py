import json
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
from glob import glob
import re
import logging

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

sns.set(style="whitegrid", font_scale=1.2)

# === Update your directories ===
json_dir = "/home/varun/code/vocab-monitor/output_learner_9/"
csv_dir = "/home/varun/code/vocab-monitor/output_learner_9_nlp/"
output_dir = "graphs_daily_learner_" + csv_dir.split("learner_")[1].split("_")[0]
os.makedirs(output_dir, exist_ok=True)

json_files = sorted(glob(os.path.join(json_dir, "*_gemini_metrics.json")))
csv_files = sorted(glob(os.path.join(csv_dir, "*_ttr_results.csv")))

def extract_yyyymmdd(filename):
    match = re.search(r"(\d{4}-\d{2}-\d{2})", filename)
    return match.group(1) if match else None

csv_dict = {extract_yyyymmdd(os.path.basename(f)): f for f in csv_files}

all_categories = [
    "Nouns", "Verbs", "Adjectives", "Adverbs", "Pronouns", "Prepositions",
    "Conjunctions", "Articles", "Interjections", "Emotion Words", "Academic Vocabulary",
    "Social Words", "Social Phrases", "Possessive Words", "Temporal Words",
    "Quantifiers", "Sensory Words", "Imaginative Words", "Question Words"
]

daily_data = []

for json_file in json_files:
    date = extract_yyyymmdd(os.path.basename(json_file))
    if not date or date not in csv_dict:
        continue

    csv_file = csv_dict[date]

    with open(json_file, "r") as f:
        data = json.load(f)
    csv_data = pd.read_csv(csv_file)

    try:
        duration_sec = float(csv_data["ASR_Conversational_Duration"].iloc[0])
        if duration_sec == 0:
            logging.warning(f"Zero duration in {csv_file}. Skipping.")
            continue
        duration_min = duration_sec / 60
    except Exception as e:
        logging.warning(f"Could not read ASR_Conversational_Duration from {csv_file}: {e}")
        continue

    vocab_count = data[-1]["Cumulative Vocabulary"]["Count"]

    category_counts = {cat: 0 for cat in all_categories}
    multi_word = 0
    single_word = 0

    for seg in data:
        wca = seg.get("Word Category Analysis", {})
        for cat in all_categories:
            category_counts[cat] += wca.get(cat, {}).get("Count", 0)

        multi_word += seg["Multi-word vs. Single-word Utterances"]["Multi-word Utterances"]["Count"]
        single_word += seg["Multi-word vs. Single-word Utterances"]["Single-word Utterances"]["Count"]

    ttr_nlp = csv_data["TTR_NLP"].iloc[0]
    mlu = csv_data["MLU"].iloc[0]

    daily_data.append({
        "Date": date,
        "VocabCount": vocab_count / duration_min,
        "MultiWord": multi_word / duration_min,
        "SingleWord": single_word / duration_min,
        "TTR_NLP": ttr_nlp,
        "MLU": mlu,
        **{cat: count / duration_min for cat, count in category_counts.items()}
    })

df = pd.DataFrame(daily_data).sort_values("Date")
df["Session"] = pd.to_datetime(df['Date']).dt.strftime('%Y-%m-%d')
df = df.set_index("Session")

def compute_rolling_averages(df, window=3):
    numeric_cols = df.select_dtypes(include="number").columns
    return df[numeric_cols].rolling(window=window, min_periods=1).mean()

rolling_window = 3  # in days
df_rolling = compute_rolling_averages(df, window=rolling_window)

# === Plot 1: Vocabulary Growth with rolling average ===
plt.figure(figsize=(20, 10))
sns.lineplot(x=df.index, y=df["VocabCount"], marker="o", color="darkblue", label="Original")
sns.lineplot(x=df_rolling.index, y=df_rolling["VocabCount"], marker="o", color="orange", label=f"{rolling_window}-Day Rolling Avg")
plt.title("Cumulative Vocabulary Growth (Normalized per Minute)")
plt.ylabel("Unique Words per Minute")
plt.xticks(rotation=45)
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "daily_vocab_growth_rolling.png"))

# === Plot 2: MLU and TTR Trends ===
plt.figure(figsize=(20, 10))
sns.lineplot(x=df.index, y=df["MLU"], marker="o", label="MLU", color="indianred")
sns.lineplot(x=df_rolling.index, y=df_rolling["MLU"], marker="o", label=f"MLU {rolling_window}-Day Rolling", color="tomato")
sns.lineplot(x=df.index, y=df["TTR_NLP"], marker="o", label="TTR", color="seagreen")
sns.lineplot(x=df_rolling.index, y=df_rolling["TTR_NLP"], marker="o", label=f"TTR {rolling_window}-Day Rolling", color="mediumseagreen")
plt.title("MLU and TTR Trends")
plt.ylabel("Score")
plt.legend()
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "daily_mlu_ttr_rolling.png"))

# === Plot 3: Multi vs. Single Word Utterances ===
utter_df = df.reset_index()[["Date", "MultiWord", "SingleWord"]].melt(id_vars="Date", var_name="Type", value_name="Count")
plt.figure(figsize=(30, 15))
sns.barplot(data=utter_df, x="Date", y="Count", hue="Type", palette="pastel", ci=None)
plt.title("Multi vs. Single Word Utterances (Normalized per Minute)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "daily_utterance_types.png"))

# === Plot 4: Word Category Usage Heatmap ===
heatmap_df = df[all_categories]
heatmap_rolling_df = df_rolling[all_categories]

plt.figure(figsize=(40, 20))
sns.heatmap(heatmap_df.T, annot=True, fmt=".2f", cmap="YlOrBr", cbar_kws={'label': 'Count/min'}, linewidths=0.5)
plt.title("Word Category Usage Over Days")
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "daily_word_categories_heatmap.png"))

plt.figure(figsize=(40, 20))
sns.heatmap(heatmap_rolling_df.T, annot=True, fmt=".2f", cmap="YlOrBr", cbar_kws={'label': f'Count/min ({rolling_window}-Day Avg)'}, linewidths=0.5)
plt.title(f"Word Category Usage ({rolling_window}-Day Rolling Avg)")
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "daily_word_categories_heatmap_rolling.png"))

# === Plot 5: Daily Word Summary HTML ===
word_data = {}

for json_file in json_files:
    date = extract_yyyymmdd(os.path.basename(json_file))
    if not date or date not in csv_dict:
        continue

    with open(json_file, "r") as f:
        data = json.load(f)

    word_freq = {}
    for seg in data:
        vocab = seg.get("Cumulative Vocabulary", {})
        words = vocab.get("Words", [])
        for w in words:
            word_freq[w] = word_freq.get(w, 0) + 1

    sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
    common_words = sorted_words[:10]
    unique_words = [w for w, freq in sorted_words if freq == 1][:10]

    word_data[date] = (common_words, unique_words)

sorted_days = sorted(word_data.keys())

html_content = """
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Daily Word Summary</title>
<style>
  body { font-family: Arial, sans-serif; margin: 20px; }
  h1 { text-align: center; }
  table { border-collapse: collapse; width: 100%; table-layout: fixed; }
  th, td { border: 1px solid #ddd; padding: 8px; vertical-align: top; word-wrap: break-word; }
  th { background-color: #f2f2f2; text-align: center; }
  .common { color: navy; font-family: monospace; }
  .unique { color: darkred; font-family: monospace; }
  tbody tr:hover { background-color: #f1f1f1; }
</style>
</head>
<body>
<h1>Daily Most Common and Unique Words Overview</h1>
<table>
<thead>
<tr>
  <th style="width: 10%;">Date</th>
  <th style="width: 45%;">Top 10 Most Common Words</th>
  <th style="width: 45%;">Top 10 Unique Words (freq=1)</th>
</tr>
</thead>
<tbody>
"""

for date in sorted_days:
    common_words, unique_words = word_data[date]
    common_html = "<br>".join([f"{w}: {freq}" for w, freq in common_words])
    unique_html = "<br>".join(unique_words)

    html_content += f"""
    <tr>
      <td style="text-align: center; font-weight: bold;">{date}</td>
      <td class="common">{common_html}</td>
      <td class="unique">{unique_html}</td>
    </tr>
    """

html_content += """
</tbody>
</table>
</body>
</html>
"""

output_html_path = os.path.join(output_dir, "daily_word_summary.html")
with open(output_html_path, "w", encoding="utf-8") as f:
    f.write(html_content)

logging.info("All graphs and HTML summaries generated successfully.")
logging.info("Output directory: %s", output_dir)
