import os
import csv
import re
import logging
from pathlib import Path
import spacy
from pysrt import open as pysrt_open
from datetime import timedelta

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

nlp = spacy.load("en_core_web_sm")

def read_srt_from_file(file_path: str):
    return pysrt_open(file_path, encoding='utf-8')

def compute_child_ttr(srt_data) -> float | None:
    tokens = []
    for subtitle in srt_data:
        if "[" in subtitle.text and "]" in subtitle.text:
            try:
                text_part, speaker = subtitle.text.rsplit("[", 1)
                speaker = speaker.rstrip("]").strip()
                if speaker.upper() != "CHILD":
                    continue
                # Remove emojis and extract words
                cleaned_text = re.sub(r"[^\w\s]", "", text_part)
                words = re.findall(r"\b\w+\b", cleaned_text.lower())
                tokens.extend(words)
            except ValueError:
                continue

    if not tokens:
        return None

    unique_words = set(tokens)
    return round(len(unique_words) / len(tokens), 4)

def compute_child_ttr_nlp(srt_data) -> float | None:
    child_text = []
    for subtitle in srt_data:
        if "[" in subtitle.text and "]" in subtitle.text:
            text_part, speaker = subtitle.text.rsplit("[", 1)
            speaker = speaker.rstrip("]").strip()
            if speaker.upper() == "CHILD":
                child_text.append(text_part.strip())

    if not child_text:
        return None

    full_text = " ".join(child_text)
    doc = nlp(full_text)

    tokens = [
        token.lemma_.lower()
        for token in doc
        if token.is_alpha and not token.is_stop
    ]

    if not tokens:
        return None

    unique_lemmas = set(tokens)
    return round(len(unique_lemmas) / len(tokens), 4)

def compute_child_mlu(srt_data) -> float | None:
    utterances = []
    for subtitle in srt_data:
        if "[" in subtitle.text and "]" in subtitle.text:
            try:
                text_part, speaker = subtitle.text.rsplit("[", 1)
                speaker = speaker.rstrip("]").strip()
                if speaker.upper() != "CHILD":
                    continue
                cleaned_text = re.sub(r"[^\w\s]", "", text_part)
                words = re.findall(r"\b\w+\b", cleaned_text)
                if words:
                    utterances.append(len(words))
            except ValueError:
                continue

    if not utterances:
        return None

    mlu = sum(utterances) / len(utterances)
    return round(mlu, 4)

def compute_conversational_duration(srt_data) -> float:
    """Compute total duration covered by subtitle segments in seconds."""
    total_duration = timedelta(seconds=0)
    for subtitle in srt_data:
        d = subtitle.duration
        duration = timedelta(hours=d.hours, minutes=d.minutes, seconds=d.seconds, milliseconds=d.milliseconds)
        total_duration += duration
    return round(total_duration.total_seconds(), 2)

def process_local_srts_and_compute_child_metrics(directory: str, output_dir: str):
    OUTPUT_DIR = Path(output_dir)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    for file in Path(directory).rglob("*.srt"):
        try:
            srt_data = read_srt_from_file(str(file))
            ttr_general = compute_child_ttr(srt_data)
            ttr_nlp = compute_child_ttr_nlp(srt_data)
            mlu = compute_child_mlu(srt_data)
            asr_duration = compute_conversational_duration(srt_data)

            if ttr_general is not None or ttr_nlp is not None or mlu is not None:
                base_name = file.stem
                output_csv = OUTPUT_DIR / f"{base_name}_ttr_results.csv"
                output_csv.parent.mkdir(parents=True, exist_ok=True)

                with open(output_csv, mode="w", newline="") as f:
                    writer = csv.writer(f)
                    writer.writerow(["File Path", "TTR_General", "TTR_NLP", "MLU", "ASR_Conversational_Duration"])
                    writer.writerow([str(file), ttr_general, ttr_nlp, mlu, asr_duration])
                    logging.info(f"TTR/MLU/ASR duration computed for: {file.name}")
            else:
                logging.warning(f"No CHILD utterances in: {file.name}")
        except Exception as e:
            logging.warning(f"Error processing {file.name}: {e}")

    logging.info(f"Finished processing all files in '{directory}'")

if __name__ == "__main__":
    local_srt_dir = "/home/varun/code/vocab-monitor/l_9_all"
    output_dir = "./output_learner_9_nlp"
    process_local_srts_and_compute_child_metrics(local_srt_dir, output_dir)
